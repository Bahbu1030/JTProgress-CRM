import os
import logging
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    client = db.Column(db.String(200), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(200), nullable=False)
    address = db.Column(db.String(500), nullable=False)
    phone = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(200), nullable=False)
    service_category = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(50), nullable=False)
    additional_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Inquiry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200), nullable=False)
    phone = db.Column(db.String(50))
    project_type = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(500), nullable=False)
    length = db.Column(db.Float, nullable=False)
    height = db.Column(db.Float, nullable=False)
    author_type = db.Column(db.String(50), nullable=False)
    plan_file_id = db.Column(db.String(200))
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status_options = ['pending', 'revision', 'en_ejecucion']

class Budget(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    obra = db.Column(db.String(200), nullable=False)
    fecha = db.Column(db.Date, nullable=False)
    dolar = db.Column(db.Float, nullable=False)
    project_type = db.Column(db.String(50), nullable=False)
    observaciones = db.Column(db.Text)
    total = db.Column(db.Float, nullable=False)
    monto_imponible = db.Column(db.Float, nullable=False)
    leyes_sociales = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    items = db.relationship('BudgetItem', backref='budget', lazy=True)

class BudgetItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    budget_id = db.Column(db.Integer, db.ForeignKey('budget.id'), nullable=False)
    code = db.Column(db.String(10), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    unit = db.Column(db.String(10), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)
    total_usd = db.Column(db.Float, nullable=False)
    total_pesos = db.Column(db.Float, nullable=False)

class Tool(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    model = db.Column(db.String(200), nullable=False)
    value = db.Column(db.Float, nullable=False)
    characteristics = db.Column(db.Text, nullable=False)
    colors = db.Column(db.String(200), nullable=False)
    purchase_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(50), nullable=False)
    responsible_name = db.Column(db.String(200))
    work_site = db.Column(db.String(500))
    borrower_name = db.Column(db.String(200))
    borrower_address = db.Column(db.String(500))
    borrower_phone = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
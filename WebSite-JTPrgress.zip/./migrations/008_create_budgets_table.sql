CREATE TABLE IF NOT EXISTS budget (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    obra VARCHAR(200) NOT NULL,
    fecha DATE NOT NULL,
    dolar DECIMAL(10,2) NOT NULL,
    project_type VARCHAR(50) NOT NULL,
    observaciones TEXT,
    total DECIMAL(10,2) NOT NULL,
    monto_imponible DECIMAL(10,2) NOT NULL,
    leyes_sociales DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS budget_item (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    budget_id INTEGER NOT NULL,
    code VARCHAR(10) NOT NULL,
    name VARCHAR(200) NOT NULL,
    unit VARCHAR(10) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_usd DECIMAL(10,2) NOT NULL,
    total_pesos DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (budget_id) REFERENCES budget(id)
);
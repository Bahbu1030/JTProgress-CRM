-- Add default user if not exists
INSERT OR IGNORE INTO user (username, password_hash)
VALUES ('Jonar1', 'pbkdf2:sha256:600000$dummyhash');
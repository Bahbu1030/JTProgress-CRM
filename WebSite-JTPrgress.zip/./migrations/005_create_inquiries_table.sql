CREATE TABLE IF NOT EXISTS inquiry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(50),
    project_type VARCHAR(100) NOT NULL,
    location VARCHAR(500) NOT NULL,
    length FLOAT NOT NULL,
    height FLOAT NOT NULL,
    author_type VARCHAR(50) NOT NULL,
    plan_file_id VARCHAR(200),
    message TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
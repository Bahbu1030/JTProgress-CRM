CREATE TABLE IF NOT EXISTS tool (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(200) NOT NULL,
    model VARCHAR(200) NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    characteristics TEXT NOT NULL,
    colors VARCHAR(200) NOT NULL,
    purchase_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL,
    responsible_name VARCHAR(200),
    work_site VARCHAR(500),
    borrower_name VARCHAR(200),
    borrower_address VARCHAR(500),
    borrower_phone VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- This is just an example, add the first migration starting with 001_*.sql

-- CREATE TABLE IF NOT EXISTS sample_table (
--     id INTEGER PRIMARY KEY AUTOINCREMENT,
--     name VARCHAR(255) UNIQUE NOT NULL
-- );
from models import BudgetItem

from models import Budget

from models import Inquiry
from flask import flash
from models import logging
from werkzeug.utils import secure_filename
import requests
from abilities import url_for_uploaded_file, download_file_from_storage
from models import Tool, Contact
import pandas as pd
from flask import Response, send_file
from io import BytesIO
from datetime import datetime
from flask import render_template, redirect, url_for, session, flash, request, jsonify
from flask import current_app as app
from abilities import flask_app_authenticator
from models import User, db
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login_route'))
        return f(*args, **kwargs)
    return decorated_function

def register_routes(app):
    @app.route("/dashboard/budgets/new", methods=['POST'])
    @login_required
    def new_budget_route():
        try:
            # Clean currency symbols and convert to float
            def clean_currency(value):
                if isinstance(value, str):
                    return float(value.replace('$', '').replace(',', '').strip())
                return float(value)
            
            # Create new budget from form data
            budget = Budget(
                obra=request.form['obra'],
                fecha=datetime.strptime(request.form['fecha'], '%Y-%m-%d'),
                dolar=clean_currency(request.form['dolar']),
                project_type=request.form['project_type'],
                observaciones=request.form.get('observaciones', ''),
                total=clean_currency(request.form['total'].replace('$', '')),
                monto_imponible=clean_currency(request.form['monto_imponible'].replace('$', '')),
                leyes_sociales=clean_currency(request.form['leyes_sociales'].replace('$', ''))
            )
            
            # Get all budget items from the form
            items_data = []
            for key in request.form:
                if key.startswith('item_'):
                    item_id = key.split('_')[1]
                    try:
                        items_data.append({
                            'code': request.form[f'code_{item_id}'],
                            'name': request.form[f'name_{item_id}'],
                            'unit': request.form[f'unit_{item_id}'],
                            'quantity': clean_currency(request.form[f'quantity_{item_id}']),
                            'unit_price': clean_currency(request.form[f'unit_price_{item_id}']),
                            'total_usd': clean_currency(request.form[f'total_usd_{item_id}'].replace('$', '')),
                            'total_pesos': clean_currency(request.form[f'total_peso_{item_id}'].replace('$', ''))
                        })
                    except KeyError as ke:
                        logger.error(f"Missing form field: {ke}")
                        return jsonify({'error': f'Campo faltante en el formulario: {ke}'}), 400
                    except ValueError as ve:
                        logger.error(f"Invalid number format: {ve}")
                        return jsonify({'error': 'Formato de número inválido'}), 400
            
            # Add budget items
            for item_data in items_data:
                item = BudgetItem(**item_data)
                budget.items.append(item)
            
            db.session.add(budget)
            db.session.commit()
            
            # Generate Excel file
            output = BytesIO()
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                # Budget details
                budget_data = {
                    'Obra': [budget.obra],
                    'Fecha': [budget.fecha.strftime('%d/%m/%Y')],
                    'Dólar': [f'${budget.dolar:.2f}'],
                    'Tipo de Proyecto': [budget.project_type],
                    'Total': [f'${budget.total:.2f}'],
                    'Monto Imponible': [f'${budget.monto_imponible:.2f}'],
                    'Leyes Sociales': [f'${budget.leyes_sociales:.2f}']
                }
                pd.DataFrame(budget_data).to_excel(writer, sheet_name='Detalles', index=False)
                
                # Budget items
                items_data = [{
                    'Código': item.code,
                    'Descripción': item.name,
                    'Unidad': item.unit,
                    'Cantidad': item.quantity,
                    'Precio Unitario (USD)': f'${item.unit_price:.2f}',
                    'Total (USD)': f'${item.total_usd:.2f}',
                    'Total (Pesos)': f'${item.total_pesos:.2f}'
                } for item in budget.items]
                pd.DataFrame(items_data).to_excel(writer, sheet_name='Items', index=False)
            
            output.seek(0)
            
            return jsonify({
                'message': 'Presupuesto guardado exitosamente',
                'budget_id': budget.id,
                'excel_url': url_for('download_budget_excel', budget_id=budget.id)
            }), 200
            
        except Exception as e:
            logger.error(f"Error creating budget: {str(e)}")
            return jsonify({'error': 'Error al guardar el presupuesto'}), 400

    @app.route("/submit-quote", methods=['POST'])
    def submit_quote():
        try:
            # Create new inquiry from form data
            inquiry = Inquiry(
                name=request.form['name'],
                email=request.form['email'],
                phone=request.form.get('phone', ''),
                project_type=request.form['project_type'],
                location=request.form['location'],
                length=float(request.form['length']),
                height=float(request.form['height']),
                author_type=request.form['author_type'],
                message=request.form['message'],
                status='pending'
            )
            
            # Handle optional plan file upload
            if 'plan_file' in request.files:
                plan_file = request.files['plan_file']
                if plan_file and plan_file.filename:
                    filename = secure_filename(plan_file.filename)
                    # TODO: Implement file storage using abilities
                    # inquiry.plan_file_id = stored_file_id
            
            db.session.add(inquiry)
            db.session.commit()
            
            flash('Su solicitud ha sido enviada exitosamente. Nos pondremos en contacto pronto.', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            logger.error(f"Error submitting quote: {str(e)}")
            flash('Hubo un error al enviar su solicitud. Por favor, intente nuevamente.', 'error')
            return redirect(url_for('index'))

    @app.route("/login", methods=['GET', 'POST'])
    def login_route():
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            
            user = User.query.filter_by(username=username).first()
            if user and password == 'Jonar01' and username == 'Jonar1':
                session['user_id'] = user.id
                session['username'] = user.username
                return redirect(url_for('dashboard_route'))
            else:
                flash('Usuario o contraseña incorrectos')
                return redirect(url_for('login_route'))
        
        return render_template("login.html")

    @app.route("/logout")
    def logout_route():
        session.clear()
        return redirect(url_for('index'))

    @app.route("/dashboard")
    @login_required
    def dashboard_route():
        return render_template("dashboard.html", username=session.get('username'))

    
    @app.route("/dashboard/tools")
    @login_required
    def tools_route():
        tools = Tool.query.order_by(Tool.created_at.desc()).all()
        return render_template("tools.html", username=session.get('username'), tools=tools)

    @app.route("/dashboard/tools/new", methods=['POST'])
    @login_required
    def new_tool_route():
        try:
            tool = Tool(
                name=request.form['name'],
                model=request.form['model'],
                value=float(request.form['value']),
                characteristics=request.form['characteristics'],
                colors=request.form['colors'],
                purchase_date=datetime.strptime(request.form['purchase_date'], '%Y-%m-%d'),
                status=request.form['status'],
                responsible_name=request.form.get('responsible_name'),
                work_site=request.form.get('work_site'),
                borrower_name=request.form.get('borrower_name'),
                borrower_address=request.form.get('borrower_address'),
                borrower_phone=request.form.get('borrower_phone')
            )
            db.session.add(tool)
            db.session.commit()
            flash('Herramienta agregada exitosamente', 'success')
        except Exception as e:
            flash(f'Error al agregar herramienta: {str(e)}', 'error')
        return redirect(url_for('tools_route'))

    @app.route("/dashboard/tools/export")
    @login_required
    def export_tools_route():
        tools = Tool.query.all()
        df = pd.DataFrame([{
            'Nombre': t.name,
            'Modelo': t.model,
            'Valor': t.value,
            'Características': t.characteristics,
            'Colores': t.colors,
            'Fecha de Compra': t.purchase_date,
            'Estado': t.status
        } for t in tools])
        
        output = BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Herramientas')
        output.seek(0)
        
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='herramientas.xlsx'
        )

    @app.route("/dashboard/tools/import", methods=['POST'])
    @login_required
    def import_tools_route():
        if 'file' not in request.files:
            flash('No se seleccionó ningún archivo', 'error')
            return redirect(url_for('tools_route'))
        
        file = request.files['file']
        if file.filename == '':
            flash('No se seleccionó ningún archivo', 'error')
            return redirect(url_for('tools_route'))
        
        try:
            df = pd.read_excel(file)
            for _, row in df.iterrows():
                tool = Tool(
                    name=row['Nombre'],
                    model=row['Modelo'],
                    value=float(row['Valor']),
                    characteristics=row['Características'],
                    colors=row['Colores'],
                    purchase_date=row['Fecha de Compra'],
                    status=row['Estado']
                )
                db.session.add(tool)
            db.session.commit()
            flash(f'Se importaron {len(df)} herramientas exitosamente', 'success')
        except Exception as e:
            flash(f'Error al importar herramientas: {str(e)}', 'error')
        return redirect(url_for('tools_route'))

    @app.route("/dashboard/clients")
    @login_required
    def clients_route():
        contacts = Contact.query.order_by(Contact.created_at.desc()).all()
        return render_template("clients.html", contacts=contacts, username=session.get('username'))

    @app.route("/dashboard/contacts/new", methods=['POST'])
    @login_required
    def new_contact_route():
        try:
            contact = Contact(
                company_name=request.form['company_name'],
                address=request.form['address'],
                phone=request.form['phone'],
                email=request.form['email'],
                service_category=request.form['service_category'],
                status=request.form['status'],
                additional_notes=request.form.get('additional_notes', '')
            )
            db.session.add(contact)
            db.session.commit()
            flash('Cliente agregado exitosamente', 'success')
        except Exception as e:
            flash(f'Error al agregar cliente: {str(e)}', 'error')
        return redirect(url_for('clients_route'))

    @app.route("/dashboard/inquiries")
    @login_required
    def inquiries_route():
        inquiries = Inquiry.query.order_by(Inquiry.created_at.desc()).all()
        return render_template("inquiries.html", username=session.get('username'), inquiries=inquiries)

    @app.route("/api/inquiries/<int:inquiry_id>")
    @login_required
    def get_inquiry_route(inquiry_id):
        inquiry = Inquiry.query.get_or_404(inquiry_id)
        if inquiry.plan_file_id:
            plan_file_url = url_for_uploaded_file(inquiry.plan_file_id)
        else:
            plan_file_url = None
        
        return jsonify({
            'id': inquiry.id,
            'name': inquiry.name,
            'email': inquiry.email,
            'phone': inquiry.phone,
            'project_type': inquiry.project_type,
            'location': inquiry.location,
            'length': inquiry.length,
            'height': inquiry.height,
            'author_type': inquiry.author_type,
            'message': inquiry.message,
            'status': inquiry.status,
            'created_at': inquiry.created_at.isoformat(),
            'plan_file_id': inquiry.plan_file_id,
            'plan_file_url': plan_file_url
        })

    @app.route("/dashboard/budgets/download/<int:budget_id>")
    @login_required
    def download_budget_excel(budget_id):
        try:
            budget = Budget.query.get_or_404(budget_id)
            
            output = BytesIO()
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                workbook = writer.book
                worksheet = workbook.add_worksheet('Presupuesto')
                
                # Format for headers
                header_format = workbook.add_format({
                    'bold': True,
                    'font_size': 12,
                    'align': 'left',
                    'valign': 'vcenter'
                })
                
                # Format for currency
                currency_format = workbook.add_format({
                    'num_format': '$#,##0.00',
                    'align': 'right'
                })
                
                # Write headers
                worksheet.write('A1', 'Obra:', header_format)
                worksheet.write('B1', budget.obra)
                worksheet.write('A2', 'Fecha:', header_format)
                worksheet.write('B2', budget.fecha.strftime('%d/%m/%Y'))
                worksheet.write('A3', 'Dólar:', header_format)
                worksheet.write('B3', budget.dolar, currency_format)
                worksheet.write('A4', 'Tipo de Proyecto:', header_format)
                worksheet.write('B4', budget.project_type)
                
                # Table headers
                headers = ['Código', 'Tipo de Trabajo', 'Unidad', 'Cantidad', 
                          'Valor U$S (unit)', 'Valor $', 'Total U$S', 'Total $']
                for col, header in enumerate(headers):
                    worksheet.write(5, col, header, header_format)
                
                # Write items
                row = 6
                for item in budget.items:
                    worksheet.write(row, 0, item.code)
                    worksheet.write(row, 1, item.name)
                    worksheet.write(row, 2, item.unit)
                    worksheet.write(row, 3, item.quantity)
                    worksheet.write(row, 4, item.unit_price, currency_format)
                    worksheet.write(row, 5, item.unit_price * budget.dolar, currency_format)
                    worksheet.write(row, 6, item.total_usd, currency_format)
                    worksheet.write(row, 7, item.total_pesos, currency_format)
                    row += 1
                
                # Write totals
                row += 1
                worksheet.write(row, 0, 'Observaciones:', header_format)
                worksheet.write(row, 1, budget.observaciones or '')
                row += 2
                worksheet.write(row, 0, 'Total:', header_format)
                worksheet.write(row, 1, budget.total, currency_format)
                row += 1
                worksheet.write(row, 0, 'Monto Imponible:', header_format)
                worksheet.write(row, 1, budget.monto_imponible, currency_format)
                row += 1
                worksheet.write(row, 0, 'Leyes Sociales:', header_format)
                worksheet.write(row, 1, budget.leyes_sociales, currency_format)
                
                # Adjust column widths
                worksheet.set_column('A:A', 15)  # Código
                worksheet.set_column('B:B', 40)  # Tipo de Trabajo
                worksheet.set_column('C:C', 10)  # Unidad
                worksheet.set_column('D:H', 15)  # Numeric columns
            
            output.seek(0)
            
            return send_file(
                output,
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                as_attachment=True,
                download_name=f'presupuesto_{budget.obra}_{budget.fecha.strftime("%Y%m%d")}.xlsx'
            )
            
        except Exception as e:
            logger.error(f"Error downloading budget excel: {str(e)}")
            return jsonify({'error': 'Error al descargar el presupuesto'}), 400

    @app.route("/dashboard/projects")
    @login_required
    def projects_route():
        return render_template("projects.html", username=session.get('username'))

    @app.route("/dashboard/budgets")
    @login_required
    def budgets_route():
        return render_template("budgets.html", username=session.get('username'))
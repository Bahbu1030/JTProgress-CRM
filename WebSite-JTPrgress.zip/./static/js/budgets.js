document.addEventListener('DOMContentLoaded', function() {
    const dolarInput = document.getElementById('dolar');
    const projectTypeSelect = document.getElementById('project_type');
    const budgetTable = document.querySelector('.budget-table tbody');
    const budgetForm = document.getElementById('budgetForm');
    
    // Work items by project type
    const workItems = {
        yeso_proyectado: [
            { code: '1.1', name: 'MOCHETAS', unit: 'ML' },
            { code: '1.2', name: 'ANTEPECHOS', unit: 'ML' },
            { code: '1.3', name: 'CANTONERAS', unit: 'ML' },
            { code: '1.4', name: 'MALLA', unit: 'M2' },
            { code: '1.5', name: 'REVOQUE TERCIADO INTERIOR', unit: 'M2' }
        ],
        revoque_2x1: [
            { code: '2.1', name: 'REVOQUE TERCIADO INTERIOR EN GARAGES', unit: 'M2' },
            { code: '2.2', name: 'PUENTE DE ADHERENCIA', unit: 'M2' },
            { code: '2.3', name: 'MALLA', unit: 'M2' },
            { code: '2.4', name: 'MOCHETAS', unit: 'ML' },
            { code: '2.5', name: 'ANTEPECHOS', unit: 'ML' },
            { code: '2.6', name: 'CANTONERAS EN REVOQUES', unit: 'ML' }
        ],
        revoque_3x1: [
            { code: '3.1', name: 'PUENTE DE ADHERENCIA', unit: 'M2' },
            { code: '3.2', name: 'MALLA', unit: 'M2' },
            { code: '3.3', name: 'CANTONERAS', unit: 'ML' },
            { code: '3.4', name: 'BUÑAS EXTERIORES', unit: 'ML' },
            { code: '3.5', name: 'MOCHETAS', unit: 'ML' },
            { code: '3.6', name: 'ANTEPECHOS', unit: 'ML' },
            { code: '3.7', name: 'REVOQUES PRETILES', unit: 'M2' }
        ],
        hormigon: [
            { code: '4.1.1', name: 'LOSAS (HORMIGÓN ARMADO)', unit: 'M3' },
            { code: '4.1.2', name: 'ENCOFRADOS', unit: 'M2' },
            { code: '4.1.3', name: 'COLUMNAS (HORMIGÓN ARMADO)', unit: 'M3' },
            { code: '4.1.4', name: 'VIGAS (HORMIGÓN ARMADO)', unit: 'M3' },
            { code: '4.1.5', name: 'MUROS DE CARGA (HORMIGÓN ARMADO)', unit: 'M3' },
            { code: '4.1.6', name: 'ZAPATAS (FUNDACIÓN)', unit: 'M3' },
            { code: '4.2.1', name: 'HORMIGÓN PROYECTADO', unit: 'M2' },
            { code: '4.2.2', name: 'HORMIGÓN IMPRESO Y ESTAMPADO', unit: 'M2' },
            { code: '4.2.3', name: 'HORMIGÓN FLOTADO', unit: 'M2' },
            { code: '4.2.4', name: 'ENLUCIDO DE HORMIGÓN', unit: 'M2' },
            { code: '4.3.1', name: 'LOSAS PREFABRICADAS', unit: 'M2' },
            { code: '4.3.2', name: 'VIGAS PREFABRICADAS', unit: 'ML' },
            { code: '4.3.3', name: 'BLOQUES DE HORMIGÓN', unit: 'UN' },
            { code: '4.4.1', name: 'INYECCIONES DE RESINAS', unit: 'ML' },
            { code: '4.4.2', name: 'COLOCACIÓN DE FIBRA DE CARBONO', unit: 'M2' },
            { code: '4.4.3', name: 'REPARACIÓN DE FISURAS Y GRIETAS', unit: 'ML' },
            { code: '4.5.1', name: 'HORMIGÓN AUTONIVELANTE', unit: 'M2' },
            { code: '4.5.2', name: 'PISCINAS', unit: 'M3' },
            { code: '4.5.3', name: 'BASES PARA MAQUINARIA', unit: 'M3' }
        ],
        drywall: [
            { code: '5.1.1', name: 'CIELOS RASOS', unit: 'M2' },
            { code: '5.1.2', name: 'PAREDES DIVISORIAS', unit: 'M2' },
            { code: '5.1.3', name: 'REVESTIMIENTOS DECORATIVOS', unit: 'M2' },
            { code: '5.2.1', name: 'UNIONES Y ESQUINAS', unit: 'ML' },
            { code: '5.2.2', name: 'LIJADO Y PREPARACIÓN PARA PINTURA', unit: 'M2' },
            { code: '5.2.3', name: 'TEXTURIZADOS', unit: 'M2' },
            { code: '5.3.1', name: 'AISLAMIENTO ACÚSTICO', unit: 'M2' },
            { code: '5.3.2', name: 'AISLAMIENTO TÉRMICO', unit: 'M2' },
            { code: '5.4.1', name: 'DISEÑO Y CONSTRUCCIÓN DE FALSOS TECHOS', unit: 'M2' },
            { code: '5.5.1', name: 'NICHOS Y ESTANTERÍAS EMPOTRADAS', unit: 'UN' },
            { code: '5.6.1', name: 'REPARACIÓN DE DAÑOS', unit: 'M2' },
            { code: '5.6.2', name: 'REVESTIMIENTOS ESPECIALES', unit: 'M2' }
        ]
    };
    
    function calculateValues(quantity, unitPrice, dolarRate) {
        const iva = 0.22; // 22% IVA
        const unitPriceWithIVA = unitPrice * (1 + iva);
        const totalUSD = quantity * unitPriceWithIVA;
        const totalPesos = totalUSD * dolarRate;
        return {
            unitPriceWithIVA,
            totalUSD,
            totalPesos
        };
    }
    
    function updateRow(row) {
        const quantity = parseFloat(row.querySelector('.quantity').value) || 0;
        const unitPrice = parseFloat(row.querySelector('.unit-price').value) || 0;
        const dolarRate = parseFloat(dolarInput.value) || 0;
        
        const values = calculateValues(quantity, unitPrice, dolarRate);
        
        row.querySelector('.peso-value').textContent = `$${values.unitPriceWithIVA * dolarRate}`;
        row.querySelector('.total-usd').textContent = `$${values.totalUSD}`;
        row.querySelector('.total-peso').textContent = `$${values.totalPesos}`;
        
        updateTotals();
    }
    
    function updateTotals() {
        let totalUSD = 0;
        let totalPesos = 0;
        
        document.querySelectorAll('.budget-row').forEach(row => {
            totalUSD += parseFloat(row.querySelector('.total-usd').textContent.replace('$', '')) || 0;
            totalPesos += parseFloat(row.querySelector('.total-peso').textContent.replace('$', '')) || 0;
        });
        
        document.getElementById('total').value = `$${totalPesos}`;
        document.getElementById('monto_imponible').value = `$${totalPesos * 0.8}`; // 80% del total
        document.getElementById('leyes_sociales').value = `$${totalPesos * 0.8 * 0.72}`; // 72% del monto imponible
    }
    
    function createBudgetRow(item, index) {
        const row = document.createElement('tr');
        row.className = 'budget-row';
        row.innerHTML = `
            <td>${item.code}</td>
            <td>${item.name}</td>
            <td>${item.unit}</td>
            <td>
                <input type="number" class="quantity" name="quantity_${index}" step="0.01" min="0">
                <input type="hidden" name="code_${index}" value="${item.code}">
                <input type="hidden" name="name_${index}" value="${item.name}">
                <input type="hidden" name="unit_${index}" value="${item.unit}">
                <input type="hidden" name="item_${index}" value="1">
            </td>
            <td>
                <input type="number" class="unit-price" name="unit_price_${index}" step="0.01" min="0"> + IVA
            </td>
            <td class="peso-value">$0</td>
            <td class="total-usd">$0</td>
            <td class="total-peso">$0</td>
        `;
        
        const inputs = row.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('input', () => updateRow(row));
        });
        
        return row;
    }
    
    projectTypeSelect.addEventListener('change', function() {
        budgetTable.innerHTML = '';
        const selectedType = this.value;
        if (workItems[selectedType]) {
            workItems[selectedType].forEach((item, index) => {
                budgetTable.appendChild(createBudgetRow(item, index));
            });
        }
    });
    
    dolarInput.addEventListener('input', function() {
        document.querySelectorAll('.budget-row').forEach(row => {
            updateRow(row);
        });
    });
    
    budgetForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Clean currency values before submission
        const cleanFormData = new FormData(this);
        const dolarValue = cleanFormData.get('dolar').replace('$', '').replace(',', '');
        cleanFormData.set('dolar', dolarValue);
        
        // Clean total values
        const totalValue = cleanFormData.get('total').replace('$', '').replace(',', '');
        cleanFormData.set('total', totalValue);
        
        const montoImponibleValue = cleanFormData.get('monto_imponible').replace('$', '').replace(',', '');
        cleanFormData.set('monto_imponible', montoImponibleValue);
        
        const leyesSocialesValue = cleanFormData.get('leyes_sociales').replace('$', '').replace(',', '');
        cleanFormData.set('leyes_sociales', leyesSocialesValue);
        
        // Clean budget items values
        document.querySelectorAll('.budget-row').forEach((row, index) => {
            const totalUsd = row.querySelector('.total-usd').textContent.replace('$', '').replace(',', '');
            const totalPeso = row.querySelector('.total-peso').textContent.replace('$', '').replace(',', '');
            cleanFormData.set(`total_usd_${index}`, totalUsd);
            cleanFormData.set(`total_peso_${index}`, totalPeso);
        });
        
        fetch('/dashboard/budgets/new', {
            method: 'POST',
            body: cleanFormData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error: ' + data.error);
            } else {
                alert('Presupuesto guardado exitosamente');
                // Download the Excel file
                window.location.href = data.excel_url;
                // Redirect to budgets list
                setTimeout(() => {
                    window.location.href = '/dashboard/budgets';
                }, 1000);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al guardar el presupuesto');
        });
    });
});
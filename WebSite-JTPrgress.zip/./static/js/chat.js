document.addEventListener('DOMContentLoaded', function() {
    // Create chat widget elements
    const chatWidget = document.createElement('div');
    chatWidget.className = 'chat-widget';
    chatWidget.innerHTML = `
        <div class="chat-bubble" onclick="toggleChat()">
            <i class="fas fa-comments"></i>
        </div>
        <div class="chat-window" id="chatWindow">
            <div class="chat-header">
                <span>Chat con JTProgress</span>
                <button onclick="toggleChat()" class="close-chat">&times;</button>
            </div>
            <div class="chat-messages" id="chatMessages">
                <div class="message bot">
                    ¡Hola! ¿En qué podemos ayudarte?
                </div>
            </div>
            <div class="chat-input">
                <input type="text" id="messageInput" placeholder="Escribe tu mensaje..." onkeypress="handleKeyPress(event)">
                <button onclick="sendMessage()">Enviar</button>
            </div>
        </div>
    `;
    document.body.appendChild(chatWidget);

    // Initialize chat state
    window.chatOpen = false;
});

function toggleChat() {
    const chatWindow = document.getElementById('chatWindow');
    window.chatOpen = !window.chatOpen;
    chatWindow.style.display = window.chatOpen ? 'flex' : 'none';
    if (window.chatOpen) {
        document.getElementById('messageInput').focus();
    }
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (message) {
        addMessage('user', message);
        input.value = '';
        
        // Simulate bot response
        setTimeout(() => {
            const response = getBotResponse(message);
            addMessage('bot', response);
        }, 1000);
    }
}

function addMessage(type, text) {
    const messages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = text;
    messages.appendChild(messageDiv);
    messages.scrollTop = messages.scrollHeight;
}

function getBotResponse(message) {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('presupuesto')) {
        return 'Para solicitar un presupuesto, puedes usar nuestro formulario en la sección de contacto o llamarnos directamente.';
    } else if (lowerMessage.includes('horario') || lowerMessage.includes('atencion')) {
        return 'Nuestro horario de atención es de lunes a viernes de 9:00 a 18:00 hrs.';
    } else if (lowerMessage.includes('ubicacion') || lowerMessage.includes('direccion')) {
        return 'Estamos ubicados en el centro de la ciudad. ¿Te gustaría coordinar una visita?';
    } else if (lowerMessage.includes('servicios')) {
        return 'Ofrecemos servicios de Yeso Proyectado, Balancin, Steel/Wood-Framing y Hormigón. ¿Sobre cuál te gustaría más información?';
    } else if (lowerMessage.includes('contacto')) {
        return 'Puedes contactarnos a través del formulario en nuestra página web o llamarnos directamente.';
    } else {
        return 'Gracias por tu mensaje. ¿En qué más puedo ayudarte?';
    }
}
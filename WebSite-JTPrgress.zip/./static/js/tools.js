function showNewToolForm() {
    document.getElementById('newToolForm').style.display = 'block';
}

function hideNewToolForm() {
    document.getElementById('newToolForm').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function() {
    const obraRadio = document.getElementById('en_obra');
    const prestadaRadio = document.getElementById('prestada');
    const obraDetails = document.getElementById('obraDetails');
    const prestadaDetails = document.getElementById('prestadaDetails');

    obraRadio.addEventListener('change', function() {
        if (obraRadio.checked) {
            obraDetails.style.display = 'block';
            prestadaDetails.style.display = 'none';
        }
    });

    prestadaRadio.addEventListener('change', function() {
        if (prestadaRadio.checked) {
            prestadaDetails.style.display = 'block';
            obraDetails.style.display = 'none';
        }
    });

    const depositoRadio = document.getElementById('en_deposito');
    depositoRadio.addEventListener('change', function() {
        if (depositoRadio.checked) {
            obraDetails.style.display = 'none';
            prestadaDetails.style.display = 'none';
        }
    });
});
function showQuoteForm() {
    document.getElementById('quoteModal').style.display = 'block';
}

function hideQuoteForm() {
    document.getElementById('quoteModal').style.display = 'none';
}

function openProjectGallery(projectId) {
    const modal = document.getElementById(`gallery-modal-${projectId}`);
    modal.style.display = 'block';
    initializeCarousel(projectId);
}

function closeProjectGallery(projectId) {
    const modal = document.getElementById(`gallery-modal-${projectId}`);
    modal.style.display = 'none';
}

function openServiceModal(serviceId) {
    const modal = document.getElementById(`service-modal-${serviceId}`);
    modal.style.display = 'block';
}

function closeServiceModal(serviceId) {
    const modal = document.getElementById(`service-modal-${serviceId}`);
    modal.style.display = 'none';
}

function initializeCarousel(projectId) {
    const carousel = document.querySelector(`#gallery-modal-${projectId} .carousel`);
    const slides = carousel.querySelectorAll('.carousel-slide');
    const dots = carousel.querySelectorAll('.carousel-dot');
    let currentSlide = 0;

    function showSlide(n) {
        slides.forEach(slide => slide.style.display = 'none');
        dots.forEach(dot => dot.classList.remove('active'));
        slides[n].style.display = 'block';
        dots[n].classList.add('active');
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    function prevSlide() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(currentSlide);
    }

    carousel.querySelector('.prev').addEventListener('click', prevSlide);
    carousel.querySelector('.next').addEventListener('click', nextSlide);
    
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentSlide = index;
            showSlide(currentSlide);
        });
    });

    showSlide(currentSlide);
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('gallery-modal')) {
        event.target.style.display = 'none';
    } else if (event.target.id === 'quoteModal') {
        event.target.style.display = 'none';
    } else if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
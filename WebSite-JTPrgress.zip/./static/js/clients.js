function showNewContactForm() {
    document.getElementById('newContactForm').style.display = 'block';
}

function hideNewContactForm() {
    document.getElementById('newContactForm').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('newContactForm');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
function showNewProjectForm() {
    document.getElementById('newProjectForm').style.display = 'block';
}

function hideNewProjectForm() {
    document.getElementById('newProjectForm').style.display = 'none';
}

function showNewContactForm() {
    document.getElementById('newContactForm').style.display = 'block';
}
function viewInquiry(inquiryId) {
    fetch(`/api/inquiries/${inquiryId}`)
        .then(response => response.json())
        .then(data => {
            const details = document.getElementById('inquiryDetails');
            details.innerHTML = `
                <div class="inquiry-detail">
                    <h3>Información del Cliente</h3>
                    <p><strong>Nombre:</strong> ${data.name}</p>
                    <p><strong>Email:</strong> ${data.email}</p>
                    <p><strong>Teléfono:</strong> ${data.phone || '-'}</p>
                    <p><strong>Fecha:</strong> ${new Date(data.created_at).toLocaleString()}</p>
                </div>
                <div class="inquiry-detail">
                    <h3>Detalles del Proyecto</h3>
                    <p><strong>Tipo:</strong> ${data.project_type}</p>
                    <p><strong>Ubicación:</strong> ${data.location}</p>
                    <p><strong>Dimensiones:</strong> ${data.length}m x ${data.height}m</p>
                    <p><strong>Tipo de Cliente:</strong> ${data.author_type}</p>
                </div>
                <div class="inquiry-detail">
                    <h3>Mensaje</h3>
                    <p>${data.message}</p>
                </div>
                ${data.plan_file_id ? `
                    <div class="inquiry-detail">
                        <h3>Planos</h3>
                        <a href="${data.plan_file_url}" target="_blank" class="download-link">
                            Ver Planos
                        </a>
                        <a href="${data.plan_file_url}" download class="download-link">
                            Descargar Archivo
                        </a>
                    </div>
                ` : ''}
            `;
            document.getElementById('inquiryModal').style.display = 'block';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar los detalles de la consulta');
        });
}

function closeInquiryModal() {
    document.getElementById('inquiryModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('inquiryModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
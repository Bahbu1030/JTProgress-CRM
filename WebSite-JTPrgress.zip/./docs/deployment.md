# Guía de Despliegue - JTProgress CRM
### Creado por MindForgeLab

## Requisitos del Sistema

### Software Necesario
- Python 3.8 o superior
- Base de datos SQLite
- Servidor web compatible con WSGI

### Requisitos de Hardware Recomendados
- CPU: 2 cores o superior
- RAM: 4GB mínimo
- Almacenamiento: 20GB mínimo

## Pasos para el Despliegue

### 1. Preparación del Servidor
1. Configure un servidor con sistema operativo Linux
2. Asegúrese de tener acceso SSH al servidor
3. Configure el firewall para permitir el puerto 80 (HTTP) y 443 (HTTPS)

### 2. Configuración del Dominio
1. Adquiera un dominio para su aplicación
2. Configure los registros DNS para apuntar a su servidor
3. (Opcional) Configure un certificado SSL

### 3. Instalación de la Aplicación
1. Copie los archivos de la aplicación al servidor
2. Configure las variables de entorno necesarias:
   ```
   SECRET_KEY=su_clave_secreta
   ```
3. Asegúrese que la carpeta 'migrations' tenga los permisos correctos

### 4. Configuración del Servidor Web
1. Configure el servidor web para servir la aplicación
2. Configure los archivos estáticos
3. Configure el proxy inverso si es necesario

### 5. Base de Datos
1. La base de datos SQLite se creará automáticamente
2. Las migraciones se aplicarán en el primer inicio

### 6. Inicio de la Aplicación
1. Inicie el servidor WSGI
2. Verifique los logs para asegurarse que todo funciona correctamente

### 7. Mantenimiento
1. Configure copias de seguridad regulares de la base de datos
2. Monitoree el uso de recursos
3. Revise los logs periódicamente

## Solución de Problemas Comunes

### Error de Permisos
- Verifique los permisos de las carpetas
- Asegúrese que el usuario del servidor web tenga acceso

### Error de Base de Datos
- Verifique que la carpeta de la base de datos tenga permisos de escritura
- Revise los logs de error

### Error de Archivos Estáticos
- Verifique la configuración del servidor web
- Asegúrese que los archivos estén en la ubicación correcta
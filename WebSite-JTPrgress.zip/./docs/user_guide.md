# Manual de Usuario - JTProgress CRM
### Creado por MindForgeLab

## Índice
1. [Introducción](#introducción)
2. [Acceso al Sistema](#acceso-al-sistema)
3. [Módulos Principales](#módulos-principales)
   - [Panel Principal](#panel-principal)
   - [Clientes](#clientes)
   - [Proyectos](#proyectos)
   - [Consultas](#consultas)
   - [Herramientas](#herramientas)
   - [Presupuestos](#presupuestos)

## Introducción
JTProgress CRM es un sistema de gestión integral diseñado específicamente para empresas constructoras. 
Permite administrar clientes, proyectos, herramientas y presupuestos de manera eficiente.

## Acceso al Sistema
1. Abra su navegador web y acceda a la URL del sistema
2. En la página principal, haga clic en "Iniciar Sesión"
3. Ingrese su nombre de usuario y contraseña
4. Haga clic en "Iniciar Sesión"

## Módulos Principales

### Panel Principal
Muestra un resumen general con:
- Proyectos activos
- Consultas pendientes
- Total de herramientas

### Clientes
Gestione la información de sus clientes:
- Agregar nuevos clientes
- Ver lista de clientes
- Actualizar información
- Seguimiento de estado

### Proyectos
Administre sus proyectos de construcción:
- Crear nuevos proyectos
- Ver estado de proyectos
- Actualizar avance
- Gestionar detalles

### Consultas
Gestione las solicitudes de presupuesto:
- Ver consultas recibidas
- Responder consultas
- Descargar planos adjuntos
- Actualizar estado

### Herramientas
Control de inventario de herramientas:
- Registrar nuevas herramientas
- Control de préstamos
- Seguimiento de ubicación
- Exportar/Importar inventario

### Presupuestos
Genere y gestione presupuestos:
1. Crear nuevo presupuesto:
   - Ingrese datos generales (obra, fecha, dólar)
   - Seleccione tipo de proyecto
   - Agregue items al presupuesto
   - Complete cantidades y precios
2. El sistema calculará automáticamente:
   - Totales en USD y pesos
   - Monto imponible
   - Leyes sociales
3. Al guardar:
   - Se genera automáticamente un archivo Excel
   - Se guarda en el sistema para consulta posterior